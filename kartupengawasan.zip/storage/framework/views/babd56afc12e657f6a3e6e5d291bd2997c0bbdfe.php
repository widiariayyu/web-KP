<?php if(Session::has('alert-success')): ?>
    <div class="alert alert-success alert-dismissable fade in">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <?php echo e(Session::get('alert-success')); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('alert-danger')): ?>
    <div class="alert alert-danger alert-dismissable fade in">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <?php echo e(Session::get('alert-danger')); ?>

    </div>
<?php endif; ?>
<?php if(Session::has('alert-warning')): ?>
    <div class="alert alert-warning alert-dismissable fade in">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <?php echo e(Session::get('alert-warning')); ?>

    </div>
<?php endif; ?>