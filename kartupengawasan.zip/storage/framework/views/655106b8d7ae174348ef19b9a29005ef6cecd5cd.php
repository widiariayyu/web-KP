<html>
<style>
	@page  :first {
		margin: 10px;
	    background: url("<?php echo e(asset('image/kartu/depan-baru.jpg')); ?>");
			background-image-resize: 6;
	}
	@page  {
	    margin: 10px;
	    background: url("<?php echo e(asset('image/kartu/belakang.jpg')); ?>");
			background-image-resize: 6;
	}
	td {
    font-family: "Courier New";
		font-size: 9px;
	}
</style>
<head>
  <title>Kartu Pengawasan Nomor : <?php echo e($data->no_kp); ?></title>
</head>
<body>
  <div style="position: absolute; bottom: 24px; right: 18px;">
    <barcode code="<?php echo e($data->mperusahaan_id.'-'.$data->nolambung); ?>" size="0.7" type="QR" error="M" class="barcode" disableborder="true"/>
  </div>
  <div style="position: absolute; top: 105px; left: 12px;">
    <table width="80%">
			<tr><td><?php echo e($data->no_kp); ?></td></tr>
			<tr><td></td></tr>
      <tr><td><?php echo e($data->no_kendaraan); ?></td></tr>
      <tr><td><?php echo e($data->pemilik); ?></td></tr>
      <tr><td><?php echo e($data->perusahaan->nama_perusahaan); ?></td></tr>
    </table>
  </div>
  <div style='page-break-after:always'></div>
</body>
</html>
