<?php $__env->startSection('adminlte_css'); ?>
    <link rel="stylesheet"
          href="<?php echo e(asset('vendor/adminlte/dist/css/skins/skin-' . config('adminlte.skin', 'blue') . '.min.css')); ?> ">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>
  <div class="wrapper">
        <br><br><br><br><br><br><br><br><br>
    <section class="content">
      <div class="error-page">
        <h2 class="headline text-yellow">404</h2>
        <div class="error-content">
          <br>
          <h3><i class="fa fa-warning text-yellow"></i> Oops! Halaman Tidak Ditemukan atau masih dalam Tahap Pengerjaan.</h3>
          <p>
            Sistem tidak bisa menemukan halaman yang anda cari.
            Anda bisa <a href="<?php echo e(URL('/')); ?>">Kembali ke Dashboard</a>.
          </p>
        </div>
      </div>
    </section>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('adminlte_js'); ?>
    <script src="<?php echo e(asset('vendor/adminlte/dist/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>