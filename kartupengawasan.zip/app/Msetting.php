<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Msetting extends Model
{
    public $timestamps = false;
    protected $guarded = ['id'];
}
