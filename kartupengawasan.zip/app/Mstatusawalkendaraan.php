<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mstatusawalkendaraan extends Model
{
    public $timestamps = false;
    protected $fillable = ['status_awal'];
}
